﻿using System;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.Shell;
using Roslyn.Compilers.CSharp;
using VSLangProj80;
using RoslynGeneratorSupport;

namespace $safeprojectname$
{
  /// <summary>
  /// When setting the 'Custom Tool' property of a C# project item to '$safeprojectname$', the
  /// ComputeNewRootNode function will get called and the result we be used to generate a new file
  /// </summary>
  [ComVisible(true)]
  [Guid("$guid1$")]
  [CodeGeneratorRegistration(typeof($safeprojectname$), "C# $safeprojectname$", vsContextGuids.vsContextGuidVCSProject, GeneratesDesignTimeSource = true)]
  [ProvideObject(typeof($safeprojectname$))]
  public class $safeprojectname$ : RoslynGenerator
  {
    // ReSharper disable InconsistentNaming
#pragma warning disable 0414
    //The name of this generator (use for 'Custom Tool' property of project item)
    internal static string name = "$safeprojectname$";
#pragma warning restore 0414
    // ReSharper restore InconsistentNaming

    protected override SyntaxNode ComputeNewRootNode(SyntaxNode rootNode)
    {
      return rootNode;
    }
  }
}